# Recording and verification script

Use a connected Android device/emulator with internet, or Chrome on the fixed port 8080. Record actual behavior; do not substitute test data screenshots.

1. Launch the app. Capture the Post Reader list with numbered posts and body previews. Pull down to refresh.
2. Tap a post. Capture Post Details, its ID, full title/body and Save to Favorites. Save twice: confirm Saved to favorites then Already in favorites.
3. Go back. Open New Post. Submit blank fields and capture validation. Enter a title/body, submit once and capture the success message and Last created post card. The demo write does not persist at the server.
4. Open Favorites. Capture the saved item. Edit note, enter a short note and Save; capture the note and confirmation.
5. Delete using the trash icon, cancel once, then confirm. Capture the empty/list state and tap Undo; verify the note returns. Swipe left to delete, then Undo again.
6. Fully close/force-stop the app (not hot reload). Reopen without clearing storage. Open Favorites and capture the saved post and exact note. On web, retain the same browser profile and localhost:8080 origin.
7. Turn internet off. Favorites/details should still be readable. Return to Posts and refresh: capture the error and Retry. Open New Post, enter valid values, submit and wait up to 15 seconds: capture the inline failure. Restore connectivity and Retry.
8. Rotate between portrait/landscape; increase system text size and check scrolling in details and both dialogs.

Submission evidence: posts.png, details.png, post_validation.png, post_success.png, post_failure.png, favorites_added.png, favorites_note.png, favorites_deleted.png, favorites_reopened.png, or one ordered recording.

Automated disk reopen tests supplement, but do not replace, step 6's full app restart evidence.
