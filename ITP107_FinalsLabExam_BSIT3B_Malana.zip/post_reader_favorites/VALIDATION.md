﻿# Validation results

Checked on 2026-10-12 with Flutter 3.27.3 / Dart 3.6.1.

- dart format lib test: completed.
- flutter analyze: zero issues.
- flutter test: all 5 tests passed.
- flutter build web: successful (build/web).
- flutter build apk --debug: blocked when Gradle download failed with java.net.UnknownHostException: services.gradle.org. No APK was produced. The generated Windows Gradle launcher was updated to quote paths containing an ampersand.
- flutter doctor also reported some Android SDK licenses unaccepted. Run flutter doctor --android-licenses interactively before Android deployment.
- Full emulator/device force-stop/reopen, airplane-mode checks and screenshots have not been captured. Follow SCREENSHOT_SCRIPT.md. The automated Hive test verified actual disk close/reopen and retained notes.
- Tests use mocked HTTP responses; they verify success/error behavior without claiming a live API/device recording.

Tests cover: persistent Hive CRUD and duplicate-note preservation; GET non-200 and POST JSON; named-route navigation, save, note edit, confirmed deletion, Undo and swipe; GET Retry, required field validation and POST success; visible POST failure retaining draft input.

The source ZIP excludes build output, local SDK paths, IDE data and dependency caches. Rebuild artifacts using README.md.
