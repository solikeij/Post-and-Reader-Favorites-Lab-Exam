import 'package:flutter/material.dart';

abstract final class AppSpacing {
  static const small = 8.0;
  static const medium = 12.0;
  static const large = 16.0;
  static const section = 24.0;
  static const radius = 12.0;
}

/// All visual tokens live here; screens inherit the same Material theme.
abstract final class AppTheme {
  static final light = _build();
  static ThemeData _build() {
    final colors = ColorScheme.fromSeed(seedColor: const Color(0xFF006B60));
    final base = ThemeData(useMaterial3: true, colorScheme: colors);
    final shape = RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppSpacing.radius));
    return base.copyWith(
      scaffoldBackgroundColor: colors.surface,
      textTheme: base.textTheme.copyWith(
        headlineMedium: base.textTheme.headlineMedium!
            .copyWith(fontSize: 28, fontWeight: FontWeight.w700),
        titleLarge: base.textTheme.titleLarge!
            .copyWith(fontSize: 22, fontWeight: FontWeight.w600),
        titleMedium: base.textTheme.titleMedium!
            .copyWith(fontSize: 16, fontWeight: FontWeight.w600),
        bodyLarge:
            base.textTheme.bodyLarge!.copyWith(fontSize: 16, height: 1.6),
        bodyMedium:
            base.textTheme.bodyMedium!.copyWith(fontSize: 14, height: 1.4),
        labelSmall: base.textTheme.labelSmall!.copyWith(fontSize: 12),
      ),
      appBarTheme: AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: colors.surface,
          foregroundColor: colors.onSurface),
      cardTheme: CardTheme(
          elevation: 0,
          color: colors.surfaceContainerLow,
          shape: shape,
          margin: const EdgeInsets.only(bottom: AppSpacing.medium)),
      elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
              backgroundColor: colors.primary,
              foregroundColor: colors.onPrimary,
              padding: const EdgeInsets.all(AppSpacing.large),
              shape: shape)),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: colors.primary,
          foregroundColor: colors.onPrimary,
          shape: shape),
      inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(AppSpacing.radius)),
          filled: true,
          fillColor: colors.surface),
      snackBarTheme:
          const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      dialogTheme: DialogTheme(shape: shape),
    );
  }
}
