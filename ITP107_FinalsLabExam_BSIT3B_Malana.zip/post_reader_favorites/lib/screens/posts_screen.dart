import 'dart:convert';
import 'package:flutter/material.dart';
import '../constants/app_routes.dart';
import '../constants/app_theme.dart';
import '../models/post.dart';
import '../services/post_api_service.dart';
import '../widgets/reader_widgets.dart';
import '../widgets/new_post_dialog.dart';

class PostsScreen extends StatefulWidget {
  const PostsScreen({super.key, this.api});
  final PostApiService? api;
  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {
  late final PostApiService _api;
  List<Post> _posts = [];
  bool _isLoading = true;
  String? _errorMessage;
  Post? _lastCreated;

  @override
  void initState() {
    super.initState();
    _api = widget.api ?? PostApiService();
    _fetchPosts();
  }

  Future<void> _fetchPosts() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final response = await _api.fetchPosts();
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as List;
        final posts = data
            .map((e) => Post.fromMap(Map<String, dynamic>.from(e as Map)))
            .toList();
        if (!mounted) return;
        setState(() {
          _posts = posts;
          _isLoading = false;
        });
      } else {
        throw Exception(
            'Failed to load posts (status ${response.statusCode}).');
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _errorMessage =
            'Could not load posts. Check your internet connection.\n$error';
        _isLoading = false;
      });
    }
  }

  Future<void> _newPost() async {
    final post = await showDialog<Post>(
        context: context,
        barrierDismissible: false,
        builder: (_) => NewPostDialog(api: _api));
    if (!mounted || post == null) return;
    setState(() => _lastCreated = post);
    showReaderMessage(context, 'Post created successfully (id: ${post.id})');
  }

  @override
  void dispose() {
    if (widget.api == null) _api.dispose();
    super.dispose();
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircularProgressIndicator(),
        SizedBox(height: AppSpacing.large),
        Text('Loading posts…'),
      ]));
    }
    if (_errorMessage != null) {
      return StatusView(
          icon: Icons.cloud_off_outlined,
          title: 'Unable to load posts',
          message: _errorMessage!,
          action: ElevatedButton.icon(
              onPressed: _fetchPosts,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry')));
    }
    if (_posts.isEmpty) {
      return StatusView(
          icon: Icons.menu_book_outlined,
          title: 'No posts yet',
          message: 'Refresh to check for something new.',
          action:
              TextButton(onPressed: _fetchPosts, child: const Text('Refresh')));
    }
    return RefreshIndicator(
        onRefresh: _fetchPosts,
        child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
              AppSpacing.large, AppSpacing.small, AppSpacing.large, 96),
          itemCount: _posts.length + 1,
          itemBuilder: (context, index) {
            if (index == 0) {
              return Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: AppSpacing.large),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Your next good read.',
                            style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: AppSpacing.small),
                        Text(
                            '${_posts.length} posts to explore. Keep the ones that matter.',
                            style: Theme.of(context).textTheme.bodyMedium),
                        if (_lastCreated != null)
                          Card(
                              child: Padding(
                                  padding:
                                      const EdgeInsets.all(AppSpacing.large),
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                            'Last created post · #${_lastCreated!.id}',
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleMedium),
                                        Text(_lastCreated!.title),
                                        Text(_lastCreated!.body),
                                        const SizedBox(
                                            height: AppSpacing.small),
                                        const Text(
                                            'Demo response only. JSONPlaceholder does not persist new posts.'),
                                      ]))),
                      ]));
            }
            final post = _posts[index - 1];
            return Card(
                child: ListTile(
              contentPadding: const EdgeInsets.all(AppSpacing.large),
              leading: CircleAvatar(child: Text('${post.id}')),
              title: Text(post.title,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text(post.body.replaceAll('\n', ' '),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.pushNamed(context, AppRoutes.details,
                  arguments: post.toMap()),
            ));
          },
        ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Post Reader'), actions: [
          IconButton(
              tooltip: 'Favorites',
              icon: const Icon(Icons.favorite_border),
              onPressed: () =>
                  Navigator.pushNamed(context, AppRoutes.favorites)),
        ]),
        body: SafeArea(child: ReaderWidth(child: _buildBody())),
        floatingActionButton: FloatingActionButton.extended(
            onPressed: _newPost,
            icon: const Icon(Icons.add),
            label: const Text('New Post')),
      );
}
