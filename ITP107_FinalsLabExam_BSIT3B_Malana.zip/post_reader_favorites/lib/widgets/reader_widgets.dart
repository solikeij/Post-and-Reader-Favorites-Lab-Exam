import 'package:flutter/material.dart';
import '../constants/app_theme.dart';

/// A centered reading column remains comfortable on phones and large displays.
class ReaderWidth extends StatelessWidget {
  const ReaderWidth({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800), child: child));
}

class StatusView extends StatelessWidget {
  const StatusView(
      {super.key,
      required this.icon,
      required this.title,
      required this.message,
      this.action});
  final IconData icon;
  final String title;
  final String message;
  final Widget? action;
  @override
  Widget build(BuildContext context) => Center(
          child: SingleChildScrollView(
        padding: const EdgeInsets.all(AppSpacing.section),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 48, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: AppSpacing.large),
          Text(title,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center),
          const SizedBox(height: AppSpacing.small),
          Text(message, textAlign: TextAlign.center),
          if (action != null)
            Padding(
                padding: const EdgeInsets.only(top: AppSpacing.large),
                child: action),
        ]),
      ));
}

void showReaderMessage(BuildContext context, String message,
    {bool error = false, SnackBarAction? action}) {
  final colors = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message,
          style: Theme.of(context)
              .textTheme
              .bodyMedium!
              .copyWith(color: error ? colors.onError : colors.onPrimary)),
      backgroundColor: error ? colors.error : colors.primary,
      action: action,
      duration: const Duration(seconds: 5),
    ));
}
